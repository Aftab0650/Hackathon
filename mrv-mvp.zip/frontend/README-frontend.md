# Frontend (PWA)
- Minimal demo forms for Agroforestry and Rice
- Wire `VITE_API` to your backend URL
- Add offline storage and map capture as next steps
