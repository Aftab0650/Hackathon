// Placeholder for offline map / polygon capture (use MapLibre or Leaflet when ready)
export default function MapField(){ return null }
