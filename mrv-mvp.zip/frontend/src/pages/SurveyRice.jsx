import React, { useState } from 'react'
import { api } from '../lib/api'

export default function SurveyRice(){
  const [form, setForm] = useState({
    farmer_id: 'FPO123-0001',
    plot_id: 'PLOT-002',
    survey_dt: new Date().toISOString().slice(0,10),
    field_area_ha: 1.0,
    water_regime: 'AWD',
    flooded_days: 50,
    straw: 'removed',
    n_fert_total_kg_ha: 90,
    transplant: true,
    transplant_date: new Date().toISOString().slice(0,10),
    variety: 'IR64',
    media: []
  })
  const [result, setResult] = useState(null)

  const submit = async () => {
    const res = await api('/surveys/rice', form)
    setResult(res)
  }

  return (
    <div>
      <h3>Rice Survey (demo)</h3>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
        <label>Area (ha) <input type="number" value={form.field_area_ha} onChange={e=>setForm({...form, field_area_ha:parseFloat(e.target.value)})}/></label>
        <label>Water Regime
          <select value={form.water_regime} onChange={e=>setForm({...form, water_regime:e.target.value})}>
            <option>CF</option><option>AWD</option><option>MSD</option>
          </select>
        </label>
        <label>Straw
          <select value={form.straw} onChange={e=>setForm({...form, straw:e.target.value})}>
            <option>removed</option><option>incorporated</option><option>burned</option>
          </select>
        </label>
        <label>N Fert (kg/ha) <input type="number" value={form.n_fert_total_kg_ha} onChange={e=>setForm({...form, n_fert_total_kg_ha:parseFloat(e.target.value)})}/></label>
      </div>
      <button style={{marginTop:12}} onClick={submit}>Submit & Estimate</button>
      {result && (
        <pre style={{background:'#f6f6f6', padding:12, marginTop:12}}>{JSON.stringify(result, null, 2)}</pre>
      )}
    </div>
  )
}
