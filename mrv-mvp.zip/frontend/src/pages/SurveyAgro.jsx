import React, { useState } from 'react'
import { api } from '../lib/api'

export default function SurveyAgro(){
  const [form, setForm] = useState({
    farmer_id: 'FPO123-0001',
    plot_id: 'PLOT-001',
    survey_dt: new Date().toISOString().slice(0,10),
    species_blocks: [
      {species_group:'Dalbergia', count:10, dbh_class:'10-20', height_class:'5-8', planting_year:2022}
    ],
    media: []
  })
  const [result, setResult] = useState(null)

  const submit = async () => {
    const res = await api('/surveys/agro', form)
    setResult(res)
  }

  return (
    <div>
      <h3>Agroforestry Survey (demo)</h3>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:8}}>
        <label>Farmer ID <input value={form.farmer_id} onChange={e=>setForm({...form, farmer_id:e.target.value})}/></label>
        <label>Plot ID <input value={form.plot_id} onChange={e=>setForm({...form, plot_id:e.target.value})}/></label>
        <label>Survey Date <input type="date" value={form.survey_dt} onChange={e=>setForm({...form, survey_dt:e.target.value})}/></label>
      </div>
      <button style={{marginTop:12}} onClick={submit}>Submit & Estimate</button>
      {result && (
        <pre style={{background:'#f6f6f6', padding:12, marginTop:12}}>{JSON.stringify(result, null, 2)}</pre>
      )}
    </div>
  )
}
