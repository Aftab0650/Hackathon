import React, { useState } from 'react'
import SurveyAgro from './pages/SurveyAgro'
import SurveyRice from './pages/SurveyRice'

export default function App(){
  const [tab, setTab] = useState('agro')
  return (
    <div style={{fontFamily: 'system-ui', padding: 16, maxWidth: 900, margin: '0 auto'}}>
      <h2>MRV — Agroforestry & Rice</h2>
      <div style={{display:'flex', gap:8, marginBottom:16}}>
        <button onClick={()=>setTab('agro')}>Agroforestry Survey</button>
        <button onClick={()=>setTab('rice')}>Rice Survey</button>
      </div>
      {tab==='agro' ? <SurveyAgro/> : <SurveyRice/>}
    </div>
  )
}
