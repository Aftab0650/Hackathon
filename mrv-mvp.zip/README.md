# MRV MVP — Agroforestry & Rice (Scalable MRV for Carbon Projects)

This is a minimal, hackathon-ready stack for **Monitoring, Reporting, Verification (MRV)** of agroforestry and rice-based carbon projects in India.

## What’s included
- **Backend (FastAPI + Postgres + PostGIS)** — survey intake, calculators, QC rules, report export.
- **Method Pack (YAML)** — region-specific emission factors & parameters (versioned).
- **DB Schema (SQL)** — farmers, plots, surveys, media, audit logs.
- **Frontend (Vite + React PWA)** — offline-first forms (basic), bilingual-ready, simple map placeholder.
- **Dockerfiles** — containerized backend; use your own Postgres or managed DB.

> This code is skeleton-level but runnable and intentionally simple for a hackathon demo.
> Extend it with real remote sensing and richer UI after the event.

## Quickstart (Dev)
1. **Backend** (Python 3.11+)
   ```bash
   cd backend
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn app.main:app --reload
   ```

2. **Frontend** (Node 18+)
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

3. **Database**
   - Create a Postgres DB and (optionally) enable PostGIS.
   - Run `database/schema.sql` to set up tables.
   - Configure `backend/.env` (see `.env.example`).

## Deploy (Docker, example for backend)
```bash
cd backend
docker build -t mrv-backend:latest .
docker run -p 8000:8000 --env-file .env mrv-backend:latest
```

## Structure
```
backend/
  app/
    main.py
    db.py
    models.py
    auth.py
    routers/
      farmers.py
      plots.py
      surveys_agro.py
      surveys_rice.py
      reports.py
      rs.py
    utils/
      calc_agro.py
      calc_rice.py
      qc.py
    method_packs/india_v1.yaml
  requirements.txt
  Dockerfile
  .env.example

database/
  schema.sql

frontend/
  index.html
  package.json
  vite.config.js
  public/manifest.webmanifest
  public/icon-192.png
  src/main.jsx
  src/App.jsx
  src/pages/SurveyAgro.jsx
  src/pages/SurveyRice.jsx
  src/components/MapField.jsx
  src/lib/api.js
  README-frontend.md
```

## Notes
- The calculators use transparent formulas with placeholders. Replace factors with your verified, cited values.
- RS (`/rs/*`) returns mock statistics—replace with real precomputed rasters or an Earth Engine bridge.
- Keep **PII minimal** and enable consent capture in the frontend.
