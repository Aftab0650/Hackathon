CREATE TABLE IF NOT EXISTS farmers (
  id SERIAL PRIMARY KEY,
  farmer_id TEXT UNIQUE NOT NULL,
  name TEXT,
  phone TEXT,
  consent BOOLEAN DEFAULT TRUE,
  language TEXT DEFAULT 'en',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS plots (
  id SERIAL PRIMARY KEY,
  farmer_id TEXT NOT NULL REFERENCES farmers(farmer_id) ON DELETE CASCADE,
  plot_id TEXT UNIQUE NOT NULL,
  area_ha NUMERIC NOT NULL,
  geometry JSONB NOT NULL,
  village TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS surveys_agro (
  id SERIAL PRIMARY KEY,
  farmer_id TEXT NOT NULL,
  plot_id TEXT NOT NULL,
  survey_dt DATE NOT NULL,
  payload JSONB NOT NULL,
  calc JSONB NOT NULL,
  qc_flags JSONB NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS surveys_rice (
  id SERIAL PRIMARY KEY,
  farmer_id TEXT NOT NULL,
  plot_id TEXT NOT NULL,
  survey_dt DATE NOT NULL,
  payload JSONB NOT NULL,
  calc JSONB NOT NULL,
  qc_flags JSONB NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);
