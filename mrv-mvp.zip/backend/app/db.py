from sqlalchemy import create_engine, text
from pydantic_settings import BaseSettings

_engine = None

class Settings(BaseSettings):
    DATABASE_URL: str
    class Config:
        env_file = ".env"

def init_engine():
    global _engine
    if _engine is None:
        settings = Settings()
        _engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
        with _engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    return _engine

def engine():
    if _engine is None:
        return init_engine()
    return _engine
