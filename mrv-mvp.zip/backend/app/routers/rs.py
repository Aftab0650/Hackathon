from fastapi import APIRouter
from ..db import engine
from sqlalchemy import text

router = APIRouter()

@router.get("/plot/{plot_id}")
def rs_stats(plot_id: str):
    # Mock RS stats — to be replaced with real precomputed rasters
    # Returns last cloud-free date, mean NDVI/EVI, canopy%
    return {
        "plot_id": plot_id,
        "last_cloudfree": "2025-08-01",
        "ndvi_mean": 0.61,
        "evi_mean": 0.41,
        "canopy_cover_pct": 32.5
    }
