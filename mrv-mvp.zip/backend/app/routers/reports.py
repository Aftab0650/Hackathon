from fastapi import APIRouter, HTTPException
from ..db import engine
from sqlalchemy import text
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import io
from fastapi.responses import StreamingResponse
import json

router = APIRouter()

@router.get("/plot/{plot_id}/summary.pdf")
def report_pdf(plot_id: str):
    sql = text("""
        SELECT p.*, 
               (SELECT json_agg(s) FROM surveys_agro s WHERE s.plot_id=p.plot_id) AS agro,
               (SELECT json_agg(s) FROM surveys_rice r WHERE r.plot_id=p.plot_id) AS rice
        FROM plots p WHERE p.plot_id=:pid
    """)
    with engine().begin() as conn:
        row = conn.execute(sql, {"pid": plot_id}).mappings().first()
    if not row:
        raise HTTPException(404, "Plot not found")

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, height-40, f"MRV Plot Summary — {plot_id}")
    c.setFont("Helvetica", 10)
    c.drawString(40, height-60, f"Farmer: {row['farmer_id']}  Area(ha): {row['area_ha']}  Village: {row.get('village','-')}")
    y = height-90
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40, y, "Agroforestry Surveys")
    y -= 16
    c.setFont("Helvetica", 9)
    if row["agro"]:
        for s in row["agro"][:6]:
            c.drawString(40, y, f"- {s['survey_dt']}  calc={s['calc']}  qc={s['qc_flags']}")
            y -= 14
            if y < 80: c.showPage(); y = height-60
    else:
        c.drawString(40, y, "None")
        y -= 14

    c.setFont("Helvetica-Bold", 12)
    c.drawString(40, y, "Rice Surveys")
    y -= 16
    c.setFont("Helvetica", 9)
    if row["rice"]:
        for s in row["rice"][:6]:
            c.drawString(40, y, f"- {s['survey_dt']}  calc={s['calc']}  qc={s['qc_flags']}")
            y -= 14
            if y < 80: c.showPage(); y = height-60
    else:
        c.drawString(40, y, "None")
        y -= 14

    c.showPage()
    c.save()
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="application/pdf",
                             headers={"Content-Disposition": f"inline; filename=plot_{plot_id}_summary.pdf"})
