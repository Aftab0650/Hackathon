from fastapi import APIRouter
from ..models import RiceSurveyCreate
from ..db import engine
from ..utils.calc_rice import estimate_rice
from ..utils.qc import qc_basic
from sqlalchemy import text
import json

router = APIRouter()

@router.post("")
def submit_rice(payload: RiceSurveyCreate):
    calc = estimate_rice(payload.model_dump())
    flags = qc_basic([m.model_dump() for m in payload.media])
    with engine().begin() as conn:
        conn.execute(text("""
            INSERT INTO surveys_rice (farmer_id, plot_id, survey_dt, payload, calc, qc_flags)
            VALUES (:farmer_id, :plot_id, :survey_dt, :payload::jsonb, :calc::jsonb, :qc_flags::jsonb)
        """), {
            "farmer_id": payload.farmer_id,
            "plot_id": payload.plot_id,
            "survey_dt": payload.survey_dt,
            "payload": json.dumps(payload.model_dump()),
            "calc": json.dumps(calc),
            "qc_flags": json.dumps(flags)
        })
    return {"ok": True, "calc": calc, "qc_flags": flags}
