from fastapi import APIRouter, HTTPException
from ..models import PlotCreate
from ..db import engine
from sqlalchemy import text
import json

router = APIRouter()

@router.post("")
def create_plot(payload: PlotCreate):
    sql = text("""
        INSERT INTO plots (farmer_id, plot_id, area_ha, geometry, village)
        VALUES (:farmer_id, :plot_id, :area_ha, :geometry::jsonb, :village)
        ON CONFLICT (plot_id) DO UPDATE SET
            area_ha=EXCLUDED.area_ha, geometry=EXCLUDED.geometry, village=EXCLUDED.village
        RETURNING *
    """)
    with engine().begin() as conn:
        row = conn.execute(sql, {
            "farmer_id": payload.farmer_id,
            "plot_id": payload.plot_id,
            "area_ha": payload.area_ha,
            "geometry": json.dumps(payload.geometry),
            "village": payload.village
        }).mappings().first()
    return dict(row)

@router.get("/{plot_id}")
def get_plot(plot_id: str):
    sql = text("SELECT * FROM plots WHERE plot_id=:pid")
    with engine().begin() as conn:
        row = conn.execute(sql, {"pid": plot_id}).mappings().first()
    if not row:
        raise HTTPException(404, "Plot not found")
    return dict(row)
