from fastapi import APIRouter, HTTPException
from ..models import FarmerCreate
from ..db import engine
from sqlalchemy import text

router = APIRouter()

@router.post("")
def create_farmer(payload: FarmerCreate):
    sql = text("""
        INSERT INTO farmers (farmer_id, name, phone, consent, language)
        VALUES (:farmer_id, :name, :phone, :consent, :language)
        ON CONFLICT (farmer_id) DO UPDATE SET
            name=EXCLUDED.name, phone=EXCLUDED.phone, consent=EXCLUDED.consent, language=EXCLUDED.language
        RETURNING id, farmer_id, name, phone, consent, language
    """)
    with engine().begin() as conn:
        row = conn.execute(sql, payload.model_dump()).mappings().first()
    return dict(row)

@router.get("/{farmer_id}")
def get_farmer(farmer_id: str):
    sql = text("SELECT * FROM farmers WHERE farmer_id=:fid")
    with engine().begin() as conn:
        row = conn.execute(sql, {"fid": farmer_id}).mappings().first()
    if not row:
        raise HTTPException(404, "Farmer not found")
    return dict(row)
