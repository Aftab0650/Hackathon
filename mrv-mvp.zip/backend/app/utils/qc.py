from typing import Dict, List

def qc_basic(media: List[Dict]) -> List[str]:
    flags = []
    if not media:
        flags.append("NO_MEDIA")
    else:
        # minimal checks
        exif_ok = sum(1 for m in media if m.get("exif") and m["exif"].get("lat") and m["exif"].get("lon"))
        if exif_ok == 0:
            flags.append("NO_EXIF_GPS")
    return flags
