from typing import Dict

# Placeholder emission factors (to be replaced with verified values)
BASE_CH4_KG_HA = 1200.0  # baseline CH4 kg/ha for continuous flooding (illustrative)
FACTOR_WATER = {"CF": 1.0, "AWD": 0.65, "MSD": 0.75}
FACTOR_STRAW = {"removed": 0.9, "incorporated": 1.1, "burned": 1.2}

GWP100_CH4 = 28.0
GWP100_N2O = 265.0

def estimate_rice(payload: Dict) -> Dict:
    area = payload["field_area_ha"]
    water = payload["water_regime"]
    straw = payload["straw"]
    n_fert = payload["n_fert_total_kg_ha"]

    ch4_kg_ha = BASE_CH4_KG_HA * FACTOR_WATER.get(water, 1.0) * FACTOR_STRAW.get(straw, 1.0)
    ch4_total = ch4_kg_ha * area
    # Very simple N2O estimate from N input (placeholder)
    n2o_kg_ha = 0.01 * n_fert
    n2o_total = n2o_kg_ha * area

    co2e = ch4_total * GWP100_CH4 + n2o_total * GWP100_N2O
    # Baseline comparison (CF + straw incorporated)
    baseline_ch4 = BASE_CH4_KG_HA * FACTOR_WATER["CF"] * FACTOR_STRAW["incorporated"] * area
    baseline_n2o = (0.01 * n_fert) * area
    baseline_co2e = baseline_ch4 * GWP100_CH4 + baseline_n2o * GWP100_N2O
    delta = baseline_co2e - co2e

    return {
        "ch4_kg": round(ch4_total, 2),
        "n2o_kg": round(n2o_total, 2),
        "co2e_kg": round(co2e, 2),
        "co2e_reduction_vs_baseline_kg": round(delta, 2),
        "uncertainty_pct": 30
    }
