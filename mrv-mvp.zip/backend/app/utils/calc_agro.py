from typing import List, Dict
from math import pi

# Very simplified allometry by DBH class and species group (placeholder values)
DBH_CLASS_MID_CM = {
    "<10": 7.5, "10-20": 15.0, "20-30": 25.0, ">30": 35.0
}
HEIGHT_CLASS_MID_M = {"<3": 2.0, "3-5": 4.0, "5-8": 6.5, ">8": 10.0}

WOOD_DENSITY = {
    "Dalbergia": 0.80, "Acacia": 0.65, "Eucalyptus": 0.55, "Other": 0.60
}

CARBON_FRACTION = 0.47
BGB_RATIO = 0.26
CO2E_RATIO = 44.0/12.0

def agb_kg(species_group: str, dbh_cm: float, height_m: float) -> float:
    # Simple cylinder proxy * density * species factor (placeholder)
    radius_m = (dbh_cm / 100.0) / 2.0
    volume_m3 = pi * (radius_m**2) * height_m * 0.5  # 0.5 form factor
    density = WOOD_DENSITY.get(species_group, WOOD_DENSITY["Other"])
    return volume_m3 * 1000.0 * density  # kg

def estimate_agro(species_blocks: List[Dict]) -> Dict:
    total_agb_kg = 0.0
    for b in species_blocks:
        dbh = DBH_CLASS_MID_CM[b["dbh_class"]]
        h = HEIGHT_CLASS_MID_M[b["height_class"]]
        group = b["species_group"]
        count = b["count"]
        total_agb_kg += agb_kg(group, dbh, h) * count

    agb_t = total_agb_kg/1000.0
    bgb_t = agb_t * BGB_RATIO
    c_t = (agb_t + bgb_t) * CARBON_FRACTION
    co2e_t = c_t * CO2E_RATIO
    return {
        "agb_t": round(agb_t, 3),
        "bgb_t": round(bgb_t, 3),
        "c_t": round(c_t, 3),
        "co2e_t": round(co2e_t, 3),
        "uncertainty_pct": 25
    }
