from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

auth_router = APIRouter()

class Login(BaseModel):
    phone_or_email: str
    otp: str

@auth_router.post("/login")
def login(payload: Login):
    # Stub: accept any OTP '000000' for demo
    if payload.otp != "000000":
        raise HTTPException(status_code=401, detail="Invalid OTP")
    return {"token":"demo-jwt", "role":"enumerator"}
