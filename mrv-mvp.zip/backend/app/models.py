from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Any, Dict

class FarmerCreate(BaseModel):
    farmer_id: str
    name: Optional[str] = None
    phone: Optional[str] = None
    consent: bool = True
    language: Optional[str] = "en"

class Farmer(FarmerCreate):
    id: int

class PlotCreate(BaseModel):
    farmer_id: str
    plot_id: str
    area_ha: float
    geometry: Dict[str, Any]  # GeoJSON
    village: Optional[str] = None

class Media(BaseModel):
    type: Literal["photo","video"]
    url: str
    ts: Optional[str] = None
    exif: Optional[Dict[str, Any]] = None

class SpeciesBlock(BaseModel):
    species_group: str
    count: int
    dbh_class: Literal["<10","10-20","20-30",">30"]
    height_class: Literal["<3","3-5","5-8",">8"]
    planting_year: Optional[int] = None

class AgroSurveyCreate(BaseModel):
    farmer_id: str
    plot_id: str
    survey_dt: str
    species_blocks: List[SpeciesBlock]
    media: List[Media] = []
    method_pack_version: str = "india_v1"

class RiceSurveyCreate(BaseModel):
    farmer_id: str
    plot_id: str
    survey_dt: str
    field_area_ha: float
    water_regime: Literal["CF","AWD","MSD"]
    flooded_days: int
    straw: Literal["removed","incorporated","burned"]
    n_fert_total_kg_ha: float
    transplant: bool = True
    transplant_date: Optional[str] = None
    variety: Optional[str] = None
    media: List[Media] = []
    method_pack_version: str = "india_v1"
