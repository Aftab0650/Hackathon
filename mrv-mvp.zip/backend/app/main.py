from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import init_engine
from .auth import auth_router
from .routers.farmers import router as farmers_router
from .routers.plots import router as plots_router
from .routers.surveys_agro import router as agro_router
from .routers.surveys_rice import router as rice_router
from .routers.reports import router as reports_router
from .routers.rs import router as rs_router

app = FastAPI(title="MRV MVP API", version="0.1.0")

from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    ORIGINS: str = "http://localhost:5173"
    class Config:
        env_file = ".env"

settings = Settings()

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.ORIGINS.split(",") if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_engine()

app.include_router(auth_router, prefix="/auth", tags=["auth"])
app.include_router(farmers_router, prefix="/farmers", tags=["farmers"])
app.include_router(plots_router, prefix="/plots", tags=["plots"])
app.include_router(agro_router, prefix="/surveys/agro", tags=["surveys-agro"])
app.include_router(rice_router, prefix="/surveys/rice", tags=["surveys-rice"])
app.include_router(reports_router, prefix="/reports", tags=["reports"])
app.include_router(rs_router, prefix="/rs", tags=["remote-sensing"])

@app.get("/health")
def health():
    return {"ok": True}
